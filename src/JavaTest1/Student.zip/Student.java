package JavaTest1;

public class Student {
        String name;
        int rollNo;
        String emailId;


        void display(){
            System.out.println(int rollNo, String name,String emailId);
        }

        public Student(){
            this.rollNo=100;
            this.name="Geetha";
            this.emailId="geetha@gmail.com";
        }

    public static void main(String[] args) {
        Student obj = new Student();
            int rollNo =  obj.rollNo;
            String name= obj.name;
            String emailId= obj.emailId;

        System.out.println(display());















    }









    }
}
